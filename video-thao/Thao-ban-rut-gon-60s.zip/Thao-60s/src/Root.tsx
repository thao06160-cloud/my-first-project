import {Composition,Folder} from "remotion";
import {ThaoFilm} from "./Composition";
import {MoDau} from "./scenes/MoDau";
import {BinhMinh} from "./scenes/BinhMinh";
import {ChanhDien} from "./scenes/ChanhDien";
import {BaiHoc} from "./scenes/BaiHoc";
import {RaVe} from "./scenes/RaVe";
import {TroLai} from "./scenes/TroLai";
export const RemotionRoot=()=> <><Composition id="Thao-MotNgay" component={ThaoFilm} durationInFrames={1809} fps={30} width={720} height={1280}/><Folder name="Canh"><Composition id="MoDau" component={MoDau} durationInFrames={210} fps={30} width={720} height={1280} /><Composition id="BinhMinh" component={BinhMinh} durationInFrames={630} fps={30} width={720} height={1280} /><Composition id="ChanhDien" component={ChanhDien} durationInFrames={426} fps={30} width={720} height={1280} /><Composition id="BaiHoc" component={BaiHoc} durationInFrames={252} fps={30} width={720} height={1280} /><Composition id="RaVe" component={RaVe} durationInFrames={171} fps={30} width={720} height={1280} /><Composition id="TroLai" component={TroLai} durationInFrames={120} fps={30} width={720} height={1280} /></Folder></>;