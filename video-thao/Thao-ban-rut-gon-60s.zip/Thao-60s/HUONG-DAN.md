# Thảo — Một ngày chậm lại

Bản dựng nháp 720×1280, 30fps, 60,3 giây. Kịch bản rút gọn còn 13 đoạn, dùng mỗi video nguồn một lần. Câu nhấn dùng chữ lớn; lời kể dùng phụ đề dưới. Hình SVG sen, mặt trời, biểu đồ và trái tim chuyển động theo từng khung hình.

Chạy: `npm ci` rồi `npm run dev -- --no-open` và chọn `Thao-MotNgay`.

Mỗi cảnh có file riêng trong `src/scenes`; footage được đặt thành từng clip độc lập. Tám video gốc nằm trong `public/clip-1.mp4` đến `clip-8.mp4`. Đã bỏ lời về ăn chay và các ý lặp để vừa nguồn. Không có footage ăn chay hoặc ghi chép trong bộ nguồn; các đoạn này dùng cảnh chùa/chánh điện minh họa.

CHƯA HOÀN TẤT ÂM THANH: người dùng đã chọn giọng nữ AI. ElevenLabs chưa có kết nối khả dụng. Video hiện tắt âm nguồn, chưa có giọng đọc. `public/loi-doc.txt` chứa lời đọc rút gọn. `public/phu-de-ban-nhap.srt` và `public/captions-draft.json` dùng nhịp đọc dự kiến, chưa căn theo âm thanh. Khi có lời đọc, cần điều chỉnh độ dài các cảnh, timing chữ và tổng thời lượng. Không xem bản này là bản thành phẩm.

ChatCut chưa được đăng ký trong phiên; chưa tạo dự án ChatCut. Remotion là bản dựng chỉnh sửa được hiện tại. Chưa xuất MP4.
