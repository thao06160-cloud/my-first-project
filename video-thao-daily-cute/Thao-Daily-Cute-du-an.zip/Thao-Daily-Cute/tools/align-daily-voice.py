"""Transcribe the uploaded Vietnamese voice locally and write source-time captions.

Run after the environment's Hugging Face network permissions are applied:
/workspace/tools/voice-align/bin/python tools/align-daily-voice.py

This script never uploads the voice to a transcription service.
"""
import json
import os
from pathlib import Path

os.environ.setdefault("HF_HOME", "/workspace/model-cache")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
from faster_whisper import WhisperModel

ROOT = Path(__file__).resolve().parents[1]
model = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=4,
                     download_root="/workspace/model-cache/whisper")
segments, info = model.transcribe(
    str(ROOT / "public/daily-vlog/voice-original.mp3"),
    language="vi", word_timestamps=True, vad_filter=True, beam_size=5,
    initial_prompt="Thảo, broker Gen Z, thị trường điều chỉnh, chánh điện, nghe pháp, ranh giới.",
)
captions = []
transcript = []
for segment in segments:
    print(f"{segment.start:.2f}–{segment.end:.2f}: {segment.text}", flush=True)
    transcript.append({"start": segment.start, "end": segment.end, "text": segment.text})
    for word in segment.words or []:
        captions.append({"text": word.word, "startMs": round(word.start * 1000),
                         "endMs": max(round(word.start * 1000) + 1, round(word.end * 1000)),
                         "timestampMs": round((word.start + word.end) * 500),
                         "confidence": round(word.probability, 4)})
if not captions:
    raise RuntimeError("No words transcribed; do not enable karaoke")
data = ROOT / "public/daily-vlog"
(data / "voice-words.json").write_text(json.dumps(captions, ensure_ascii=False, indent=2))
(data / "voice-transcript.json").write_text(json.dumps(transcript, ensure_ascii=False, indent=2))
# Review the transcript and adjust editorial keyword windows before enabling.
(ROOT / "src/DailyWords.ts").write_text(
    "import type {Caption} from '@remotion/captions';\n"
    "export const alignmentVerified = true;\n"
    "export const alignedWords: Caption[] = " + json.dumps(captions, ensure_ascii=False, indent=2) + ";\n"
)
print("Wrote word timings. Review transcription and keyword windows against the voice before delivery.")
