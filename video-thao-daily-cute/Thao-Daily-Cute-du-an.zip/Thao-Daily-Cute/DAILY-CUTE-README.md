# Bản dựng mới: Thao-Daily-Cute

## Đã thực hiện

- Giữ bản dựng cũ `Thao-MotNgay`; thêm composition riêng `Thao-Daily-Cute`.
- Thứ tự đã được người dùng xác nhận: văn phòng → họp → chùa buổi tối → selfie → sân chùa → chánh điện → selfie → làm việc.
- Hook lưới 2×2 có bốn ô bằng nhau, viền và khe 12px, tông kem/hồng, font tiếng Việt Baloo 2 và Be Vietnam Pro.
- Ô hook: bảng giá minh họa chuyển động (tự tạo vì thiếu screen recording), footage làm việc, selfie, chánh điện. Ảnh chân dung đính kèm chưa có tệp cục bộ, nên ô trên phải hiện dùng footage làm việc.
- Voice MP3 gốc 66,096 giây đã gắn vào timeline; clip nguồn tắt tiếng để tránh lẫn âm.
- Đã bỏ bản MP3 và clip 2790 gửi trùng theo SHA-256.
- Zoom nhẹ, paper wipe, flash dịu, âm thanh pop/chime/swoosh tự tổng hợp.
- Component karaoke đổi màu từng từ và tự ẩn trong các cửa sổ keyword/hook.

## Chưa hoàn tất — không gọi đây là bản karaoke đã căn voice

Model nhận dạng tiếng Việt bị mạng chặn tại `huggingface.co` (HTTP CONNECT 403).
Yêu cầu các miền `huggingface.co`, `*.huggingface.co`, `*.hf.co` đã lưu vào cấu hình nháp của môi trường.
Người dùng cần lưu và Publish thay đổi trong cài đặt môi trường, sau đó kiểm tra kết nối lại.

`src/DailyWords.ts` hiện để trống và `alignmentVerified=false`; không lấy kịch bản cũ giả làm transcript voice mới.
Các keyword và cửa sổ chữ nhấn hiện là nháp biên tập dựa trên nội dung dự án trước, cần đối chiếu voice thực tế và chỉnh sau khi nhận dạng.
Chưa cắt voice: cần có transcript trước để tránh cắt mất ý. Chưa xuất MP4 hoàn chỉnh.

## Tiếp tục

1. Sau khi quyền mạng được áp dụng: `/workspace/tools/voice-align/bin/python tools/align-daily-voice.py`.
2. Đọc `public/daily-vlog/voice-transcript.json`, sửa lỗi tên riêng/từ tiếng Việt; đối chiếu thời gian các từ với âm thanh. Chỉnh `emphasisWindows` và độ dài cảnh theo voice.
3. Chỉ giữ subtitle ở đoạn không có keyword; chữ keyword lớn, đậm. Không đổi thứ tự clip đã xác nhận.
4. `npm run lint` và `npm run build`.
5. `npm run dev -- --no-open --port=3000`, chọn `Thao-Daily-Cute`. Có composition hook riêng `Thao-Hook-4-O` để chỉnh bốn ô.

Nguồn tải lên giữ tại `/workspace/attachments/manifest.json`; tài nguyên bản dựng nằm trong `public/daily-vlog/`.
