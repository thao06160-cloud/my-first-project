import type {Caption} from '@remotion/captions';

// Intentionally empty until the actual uploaded voice has been transcribed.
// Never substitute the old draft script for a verified transcript.
export const alignmentVerified = false;
export const alignedWords: Caption[] = [];
