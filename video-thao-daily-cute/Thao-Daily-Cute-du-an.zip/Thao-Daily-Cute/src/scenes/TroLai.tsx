import {AbsoluteFill, Sequence, staticFile, useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';
import {TextLayer} from '../TextLayer';
export const TroLai=()=>{const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#182921'}}><Sequence name="Footage 1" durationInFrames={120} premountFor={fps}><Video src={staticFile("clip-8.mp4")} objectFit="cover" muted premountFor={fps} style={{width:"100%",height:"100%"}} /></Sequence><TextLayer label="05 / TIẾP TỤC TIẾN BỘ" icon="heart" captions={[{"text": "Thị trường điều chỉnh, Thảo cũng điều chỉnh bản thân!", "startMs": 0, "endMs": 4000, "timestampMs": null, "confidence": null, "hero": true}]} /></AbsoluteFill>};
