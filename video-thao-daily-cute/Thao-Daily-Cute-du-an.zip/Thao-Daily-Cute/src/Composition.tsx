import {Series,useVideoConfig} from "remotion";
import {MoDau} from "./scenes/MoDau";
import {BinhMinh} from "./scenes/BinhMinh";
import {ChanhDien} from "./scenes/ChanhDien";
import {BaiHoc} from "./scenes/BaiHoc";
import {RaVe} from "./scenes/RaVe";
import {TroLai} from "./scenes/TroLai";
export const ThaoFilm=()=>{const {fps}=useVideoConfig();return <Series><Series.Sequence name="MỘT NGÀY CỦA THẢO" durationInFrames={210} premountFor={fps}><MoDau/></Series.Sequence><Series.Sequence name="01 / CHẬM LẠI" durationInFrames={630} premountFor={fps}><BinhMinh/></Series.Sequence><Series.Sequence name="02 / LẮNG NGHE" durationInFrames={426} premountFor={fps}><ChanhDien/></Series.Sequence><Series.Sequence name="03 / NHÌN LẠI" durationInFrames={252} premountFor={fps}><BaiHoc/></Series.Sequence><Series.Sequence name="04 / BÌNH TĨNH HƠN" durationInFrames={171} premountFor={fps}><RaVe/></Series.Sequence><Series.Sequence name="05 / TIẾP TỤC TIẾN BỘ" durationInFrames={120} premountFor={fps}><TroLai/></Series.Sequence></Series>};