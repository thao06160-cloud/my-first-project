import React from 'react';
import {Audio, Video} from '@remotion/media';
import {loadFont} from '@remotion/fonts';
import {AbsoluteFill, Composition, Freeze, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import type {Caption} from '@remotion/captions';
import {alignedWords, alignmentVerified} from './DailyWords';

const asset = (name: string) => staticFile(`daily-vlog/${name}`);
const cream = '#fff8eb';
const pink = '#ffc8e1';
const ink = '#492936';
const butter = '#fff293';
const fontReady = Promise.all([
  loadFont({family: 'Baloo', url: asset('fonts/Baloo2.ttf'), weight: '400 800'}),
  loadFont({family: 'Vietnam', url: asset('fonts/BeVietnamPro-Bold.ttf'), weight: '700'}),
  loadFont({family: 'Vietnam', url: asset('fonts/BeVietnamPro-Medium.ttf'), weight: '500'}),
]);
void fontReady;

// These graphic accents are one reusable animated template, not timeline clips.
const Flower: React.FC<{x: number; y: number; size?: number; color?: string; delay?: number}> = ({x, y, size = 86, color = pink, delay = 0}) => {
  const frame = useCurrentFrame(); const {fps} = useVideoConfig();
  return <svg width={size} height={size} viewBox="0 0 100 100" style={{position: 'absolute', left: x, top: y, rotate: `${Math.sin((frame + delay) / 28) * 12}deg`, scale: spring({fps, frame: frame - delay, config: {damping: 12}}), filter: 'drop-shadow(0px 4px 0px #49293622)'}}>
    {[0, 60, 120, 180, 240, 300].map(a => <ellipse key={a} cx="50" cy="26" rx="15" ry="23" fill={color} stroke={cream} strokeWidth="3" transform={`rotate(${a} 50 50)`}/>)}
    <circle cx="50" cy="50" r="16" fill={butter}/><circle cx="45" cy="48" r="1.8" fill={ink}/><circle cx="55" cy="48" r="1.8" fill={ink}/><path d="M45 54 Q50 59 55 54" fill="none" stroke={ink} strokeWidth="2" strokeLinecap="round"/>
  </svg>;
};

const Sparkle: React.FC<{x: number; y: number; size?: number}> = ({x, y, size = 52}) => {
  const f = useCurrentFrame();
  return <svg width={size} height={size} viewBox="0 0 100 100" style={{position: 'absolute', left: x, top: y, scale: 0.8 + Math.sin(f / 9) * 0.16, rotate: `${Math.sin(f / 24) * 8}deg`}}><path d="M50 3 Q54 43 97 50 Q55 55 50 97 Q44 55 3 50 Q44 44 50 3" fill={butter} stroke={cream} strokeWidth="4"/></svg>;
};

const Label: React.FC<{children: React.ReactNode; top?: number}> = ({children, top = 66}) => <div style={{position: 'absolute', top, left: 42, background: cream, color: ink, padding: '8px 22px', borderRadius: 100, fontFamily: 'Vietnam', fontWeight: 700, fontSize: 18, letterSpacing: 2, boxShadow: '0 4px 0 #49293620'}}>{children}</div>;

const MarketBoard = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{background: '#1e2e31', padding: 24, color: cream, fontFamily: 'Vietnam'}}>
    <div style={{fontSize: 16, letterSpacing: 3, opacity: 0.7, marginTop: 20}}>THỊ TRƯỜNG HÔM NAY</div>
    <div style={{fontSize: 55, fontWeight: 700, color: '#ffb7c8', marginTop: 14}}>↘ ↗ ↘</div>
    <svg viewBox="0 0 300 350" style={{width: '100%', height: 350}}>
      {[50, 110, 170, 230, 290].map(y => <path key={y} d={`M0 ${y} H300`} stroke="#ffffff12"/>)}
      {Array.from({length: 22}, (_, i) => {const y = 120 + Math.sin(i * 0.8) * 45 + i * 2.5; const down = i % 3 === 0; return <g key={i} opacity={interpolate(frame, [i * 1.5, i * 1.5 + 8], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}><path d={`M${i * 14} ${y - 28} V${y + 34}`} stroke={down ? '#ff8da4' : '#9ce8c6'} strokeWidth="2"/><rect x={i * 14 - 4} y={y - 16} width="8" height="34" rx="2" fill={down ? '#ff8da4' : '#9ce8c6'}/></g>;})}
      <path d="M0 200 Q40 260 80 220 T160 210 T240 265 L300 250" fill="none" stroke="#c0acff" strokeWidth="4"/>
    </svg>
    <div style={{fontSize: 12, opacity: 0.5}}>BẢNG GIÁ MINH HỌA</div>
  </AbsoluteFill>;
};

export const CuteHook = () => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: cream, fontFamily: 'Baloo', overflow: 'hidden'}}>
    <div style={{position: 'absolute', inset: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '1fr 1fr', gap: 12}}>
      <div style={{position: 'relative', overflow: 'hidden', borderRadius: 20}}><MarketBoard/></div>
      <div style={{position: 'relative', overflow: 'hidden', borderRadius: 20}}><Video name="Hook / làm việc" src={asset('2878.mp4')} playbackRate={0.8} muted objectFit="cover" premountFor={fps} style={{width: '100%', height: '100%'}}/></div>
      <div style={{position: 'relative', overflow: 'hidden', borderRadius: 20}}><Video name="Hook / selfie" src={asset('2809.mp4')} muted objectFit="cover" premountFor={fps} style={{width: '100%', height: '100%'}}/></div>
      <div style={{position: 'relative', overflow: 'hidden', borderRadius: 20}}><Video name="Hook / chánh điện" src={asset('2826.mp4')} playbackRate={0.55} muted objectFit="cover" premountFor={fps} style={{width: '100%', height: '100%'}}/></div>
    </div>
    <AbsoluteFill style={{background: 'linear-gradient(transparent 20%, #27202725 33%, #27202755 56%, transparent 85%)'}}/>
    <Label>một ngày của Thảo ✦</Label>
    <div style={{position: 'absolute', top: 300, left: 22, right: 22, textAlign: 'center', color: cream, fontWeight: 800, lineHeight: 1.04, scale: spring({fps, frame: f, config: {damping: 14}})}}>
      <div style={{fontSize: 67, WebkitTextStroke: `2px ${ink}`, paintOrder: 'stroke fill', textShadow: `0 5px 0 ${ink}`}}>THỊ TRƯỜNG</div>
      <div style={{fontSize: 65, color: butter, WebkitTextStroke: `2px ${ink}`, paintOrder: 'stroke fill', textShadow: `0 5px 0 ${ink}`}}>ĐIỀU CHỈNH...</div>
      <div style={{color: pink, fontSize: 126, lineHeight: 1.05, marginTop: 15, rotate: '-5deg', WebkitTextStroke: `3px ${ink}`, paintOrder: 'stroke fill', textShadow: `0 6px 0 ${ink}`}}>Gen Z</div>
      <div style={{display: 'inline-block', padding: '6px 38px 12px', background: cream, color: ink, border: `3px solid ${ink}`, borderRadius: '45% 45% 40% 40%', fontSize: 75, rotate: '3deg', marginTop: 10, boxShadow: `0 6px 0 ${pink}`}}>làm gì?</div>
    </div>
    <Flower x={38} y={760} size={95}/><Sparkle x={590} y={315} size={68}/><Sparkle x={550} y={812} size={44}/>
  </AbsoluteFill>;
};

const Footage: React.FC<{src: string; rate?: number; zoom?: number; position?: string}> = ({src, rate = 1, zoom = 1.06, position = 'center'}) => {
  const f = useCurrentFrame(); const {fps, durationInFrames} = useVideoConfig();
  return <AbsoluteFill style={{overflow: 'hidden', background: '#292329'}}>
    <Video name={src} src={asset(src)} muted objectFit="cover" playbackRate={rate} premountFor={fps} style={{width: '100%', height: '100%', objectPosition: position, scale: interpolate(f, [0, durationInFrames - 1], [1, zoom], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), filter: 'saturate(1.04) brightness(1.025)'}}/>
    <AbsoluteFill style={{background: 'linear-gradient(#00000025,transparent 22%,transparent 65%,#1a102145)'}}/>
  </AbsoluteFill>;
};

// The cover/hold is generated from the user's own footage, never a new face.
const PortraitHold = ({src, at}: {src: string; at: number}) => <Freeze frame={at}><Footage src={src} zoom={1}/></Freeze>;

type Emphasis = {start: number; end: number; small: string; big: string; sub?: string; flower?: boolean};
// Editorial emphasis windows are provisional until the voice alignment is available.
export const emphasisWindows: Emphasis[] = [
  {start: 0, end: 4.5, small: '', big: ''},
  {start: 4.5, end: 7.5, small: 'hôm nay, Thảo thử...', big: 'TU MỘT NGÀY', sub: 'cho tâm trí nghỉ một chút ♡', flower: true},
  {start: 23.8, end: 27.2, small: 'sau những phiên', big: 'XANH ↗ ĐỎ ↘', flower: false},
  {start: 47.5, end: 51.4, small: 'không có con đường cùng', big: 'CHỈ CÓ NHỮNG\nRANH GIỚI', flower: true},
  {start: 57.8, end: 61.7, small: 'chưa đúng thì xem lại', big: 'CHƯA BIẾT?\nHỌC THÊM!', flower: true},
  {start: 62, end: 66.1, small: 'thị trường điều chỉnh', big: 'THẢO CŨNG\nĐIỀU CHỈNH', sub: 'bản thân, mỗi ngày một chút ♡', flower: true},
];

const Keywords = () => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const s = f / fps;
  const item = emphasisWindows.find(w => s >= w.start && s < w.end);
  if (!item || !item.big) return null;
  const local = f - item.start * fps;
  return <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 35px 236px', alignItems: 'center', color: ink, textAlign: 'center', pointerEvents: 'none'}}>
    <div style={{position: 'relative', width: '100%', padding: '25px 18px 28px', background: '#fff8ebf5', borderRadius: 34, border: `3px solid ${ink}`, boxShadow: `8px 9px 0 ${pink}`, rotate: `${Math.sin(local / 17) * 1.2 - 1}deg`, scale: spring({fps, frame: local, config: {damping: 14}})}}>
      <div style={{fontFamily: 'Vietnam', fontWeight: 700, fontSize: 25, marginBottom: 9}}>{item.small}</div>
      <div style={{fontFamily: 'Baloo', fontWeight: 800, fontSize: 65, lineHeight: 1.13, whiteSpace: 'pre-line', color: '#803957'}}>{item.big}</div>
      {item.sub && <div style={{fontFamily: 'Vietnam', fontSize: 23, fontWeight: 500, marginTop: 13}}>{item.sub}</div>}
      {item.flower && <Flower x={-24} y={-47} size={75}/>}
      <Sparkle x={550} y={-26} size={48}/>
    </div>
  </AbsoluteFill>;
};

// Custom karaoke is needed for the precise pink word highlight requested.
// Each Caption remains timed relative to the original voice file.
const Karaoke = ({captions}: {captions: Caption[]}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const ms = f / fps * 1000;
  if (!alignmentVerified || emphasisWindows.some(w => ms >= w.start * 1000 && ms < w.end * 1000)) return null;
  const pages: Caption[][] = []; let current: Caption[] = [];
  for (const word of captions) {
    current.push(word);
    if (current.length >= 6 || /[.!?,…:;]$/.test(word.text.trim()) || word.pageBreakAfter) {pages.push(current); current = [];}
  }
  if (current.length) pages.push(current);
  const page = pages.find(p => ms >= p[0].startMs && ms < p[p.length - 1].endMs + 80);
  if (!page) return null;
  return <div style={{position: 'absolute', bottom: 224, left: 44, right: 44, display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '4px 7px', fontFamily: 'Vietnam', fontWeight: 700, fontSize: 34, lineHeight: 1.55, textAlign: 'center'}}>
    {page.map((word, i) => {const active = ms >= word.startMs && ms < word.endMs; return <span key={i} style={{padding: '1px 9px', background: active ? pink : '#29202ba8', color: active ? ink : cream, borderRadius: 12, boxShadow: active ? '0 4px 0 #fff8eb' : undefined, scale: active ? 1.08 : 1}}>{word.text.trim()}</span>;})}
  </div>;
};

const PaperWipe = ({kind = 'wipe'}: {kind?: 'wipe' | 'flash'}) => {
  const f = useCurrentFrame();
  if (kind === 'flash') return <AbsoluteFill style={{background: cream, opacity: interpolate(f, [0, 4, 12], [0, 0.8, 0], {extrapolateRight: 'clamp'})}}/>;
  return <AbsoluteFill style={{background: pink, translate: `${interpolate(f, [0, 7, 14], [-105, 0, 105], {extrapolateRight: 'clamp'})}% 0px`, rotate: '-5deg', scale: 1.2}}><Flower x={300} y={560} size={120}/></AbsoluteFill>;
};

export const DailyCute = () => {
  const {fps} = useVideoConfig();
  return <AbsoluteFill style={{background: cream, fontFamily: 'Vietnam'}}>
    <Sequence name="HOOK / 4 ô cân đều" durationInFrames={135} premountFor={fps}><CuteHook/></Sequence>
    <Sequence name="01 / Văn phòng" from={135} durationInFrames={90} premountFor={fps}><Footage src="2790.mp4" zoom={1.035}/><Label>01 ✦ một ngày khác thường</Label></Sequence>
    <Sequence name="02 / Họp" from={225} durationInFrames={231} premountFor={fps}><Footage src="meeting.mp4" zoom={1.045}/><Label>công việc thường ngày</Label></Sequence>
    <Sequence name="03 / Chùa buổi tối" from={456} durationInFrames={330} premountFor={fps}><Footage src="2852.mp4" zoom={1.06}/><Label>02 ✦ thử chậm lại một chút</Label></Sequence>
    <Sequence name="04 / Selfie ngoài chùa" from={786} durationInFrames={330} premountFor={fps}><Footage src="2819.mp4" zoom={1.035}/><Label>một khoảng thở cho mình ♡</Label></Sequence>
    <Sequence name="05 / Sân chùa" from={1116} durationInFrames={240} premountFor={fps}><Footage src="2843.mp4" zoom={1.06}/><Label>03 ✦ lắng nghe & nhìn lại</Label></Sequence>
    <Sequence name="06 / Chánh điện" from={1356} durationInFrames={80} premountFor={fps}><Footage src="2826.mp4" zoom={1.025}/></Sequence>
    <Sequence name="07 / Nghe pháp" from={1436} durationInFrames={193} premountFor={fps}><Footage src="2835.mp4" zoom={1.035}/></Sequence>
    <Sequence name="08 / Selfie" from={1629} durationInFrames={30} premountFor={fps}><Footage src="2885.mp4" zoom={1.02}/></Sequence>
    <Sequence name="08b / Khoảnh khắc" from={1659} durationInFrames={33} premountFor={fps}><PortraitHold src="2885.mp4" at={26}/></Sequence>
    <Sequence name="09 / Trở lại làm việc" from={1692} durationInFrames={192} premountFor={fps}><Footage src="2878.mp4" rate={0.65} zoom={1.05}/><Label>04 ✦ tiếp tục tiến bộ</Label></Sequence>
    <Sequence name="Kết / giữ khoảnh khắc" from={1884} durationInFrames={99} premountFor={fps}><PortraitHold src="2878.mp4" at={125}/></Sequence>

    <Sequence name="Voice / bản gốc 66 giây" durationInFrames={1983} premountFor={fps}><Audio src={asset('voice-original.mp3')} premountFor={fps} volume={1}/><Karaoke captions={alignedWords}/></Sequence>
    <Keywords/>

    <Sequence name="Chuyển / hook → văn phòng" from={128} durationInFrames={15} premountFor={fps}><PaperWipe/><Audio src={asset('swoosh.wav')} premountFor={fps} volume={0.32}/></Sequence>
    <Sequence name="Chuyển / công việc → chùa" from={449} durationInFrames={15} premountFor={fps}><PaperWipe/><Audio src={asset('swoosh.wav')} premountFor={fps} volume={0.28}/></Sequence>
    <Sequence name="Chuyển / selfie → sân chùa" from={1112} durationInFrames={13} premountFor={fps}><PaperWipe kind="flash"/><Audio src={asset('pop.wav')} premountFor={fps} volume={0.32}/></Sequence>
    <Sequence name="Chuyển / nhìn lại → làm việc" from={1685} durationInFrames={15} premountFor={fps}><PaperWipe/><Audio src={asset('swoosh.wav')} premountFor={fps} volume={0.28}/></Sequence>
    <Audio name="Pop / hook" src={asset('pop.wav')} premountFor={fps} volume={0.4}/>
    <Audio name="Ding / đi tu một ngày" src={asset('chime.wav')} from={135} premountFor={fps} volume={0.3}/>
    <Audio name="Ding / câu chốt" src={asset('chime.wav')} from={1860} premountFor={fps} volume={0.3}/>
  </AbsoluteFill>;
};

export const DailyCuteRegistrations = () => <>
  <Composition id="Thao-Daily-Cute" component={DailyCute} width={720} height={1280} fps={30} durationInFrames={1983}/>
  <Composition id="Thao-Hook-4-O" component={CuteHook} width={720} height={1280} fps={30} durationInFrames={135}/>
</>;
