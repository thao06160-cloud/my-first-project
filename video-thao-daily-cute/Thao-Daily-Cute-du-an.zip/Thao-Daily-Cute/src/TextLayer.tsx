import {AbsoluteFill,interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import type {Caption} from '@remotion/captions';
type Props={label:string;icon:string;captions:(Caption & {hero:boolean})[]};
const Graphic=({kind,frame}:{kind:string;frame:number})=>{
 const pulse=1+Math.sin(frame/13)*.045;
 return <svg width="78" height="78" viewBox="0 0 100 100" style={{scale:String(pulse)}} fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
 {kind==='sun'?<><circle cx="50" cy="48" r="17"/><path d="M50 13v8m0 54v8M15 48h8m54 0h8M25 23l6 6m38 38 6 6M25 73l6-6m38-38 6-6M15 88h70"/></>:kind==='chart'?<><path d="M13 16v70h76M22 64l16-19 14 10 25-31M65 24h12v12"/><path stroke="#e5bdb9" d="M27 76v-9m17 9V63m17 13V53m17 23V43"/></>:kind==='heart'?<path d="M50 81S12 58 12 34C12 11 43 10 50 31c7-21 38-20 38 3C88 58 50 81 50 81Z"/>:<><path d="M50 78C26 66 28 42 50 17c22 25 24 49 0 61Z"/><path d="M49 80C20 80 10 57 15 36c24 5 36 20 34 44Zm2 0c29 0 39-23 34-44-24 5-36 20-34 44Z"/><path d="M19 86h62"/></>}
 </svg>
};
export const TextLayer=({label,icon,captions}:Props)=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const ms=frame/fps*1000;
 const caption=captions.find(c=>ms>=c.startMs&&ms<c.endMs);
 const local=caption?(ms-caption.startMs)/1000*fps:0;
 const appear=interpolate(local,[0,8],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{fontFamily:'Arial, sans-serif',color:'#fffdf5',pointerEvents:'none'}}>
 <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(11,25,19,.66) 0%,transparent 35%,transparent 51%,rgba(8,20,15,.88) 100%)'}}/>
 <div style={{position:'absolute',left:42,right:65,top:66,display:'flex',alignItems:'center',gap:14,fontSize:16,letterSpacing:2,fontWeight:700}}><span style={{width:26,height:2,background:'#ecdbb0'}}/>{label}</div>
 <div style={{position:'absolute',right:48,top:113,color:'#ecdbb0',opacity:.92}}><Graphic kind={icon} frame={frame}/></div>
 {caption&&<div style={{position:'absolute',left:44,right:70,bottom:caption.hero?238:170,opacity:appear,translate:`0px ${Math.round((1-appear)*16)}px`}}>
 {caption.hero?<><div style={{fontSize:14,letterSpacing:3,marginBottom:15,color:'#ecdbb0'}}>THẢO / NHẬT KÝ LÀM NGHỀ</div><div style={{fontSize:caption.text.length>65?39:46,lineHeight:1.2,fontWeight:800,textShadow:'0 2px 18px #08140f',textWrap:'balance'}}>{caption.text}</div><div style={{height:4,width:74,background:'#e5bdb9',marginTop:24,borderRadius:4}}/></>:<div style={{fontSize:31,lineHeight:1.32,fontWeight:600,textAlign:'center',padding:'16px 18px',borderRadius:16,background:'rgba(11,25,19,.68)',textShadow:'0 2px 6px #000',textWrap:'balance'}}>{caption.text}</div>}
 </div>}
 <div style={{position:'absolute',bottom:66,left:44,fontSize:13,letterSpacing:2,color:'#e8ddc8'}}>THẢO · MỘT NGÀY CHẬM LẠI</div>
 </AbsoluteFill>
};
